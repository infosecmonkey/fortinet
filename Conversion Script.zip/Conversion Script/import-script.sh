#!/bin/bash
IMPORT="/Users/mannyfernandez/Desktop/Script/source"
TEMPLATE="/Users/mannyfernandez/Desktop/Script/template"

for i in `cat ${IMPORT}`
do 
  VAR_HOSTNAME=`echo $i | awk -F, '{print $1}'`
  VAR_IPADDR=`echo $i | awk -F, '{print $2}'`
  cat $TEMPLATE | sed -e s/VAR_HOSTNAME/$VAR_HOSTNAME/g \
                      -e s/VAR_IPADDR/$VAR_IPADDR/g \
                | tee -a  ///Users/mannyfernandez/Desktop/Script/output 1>/dev/null
done

